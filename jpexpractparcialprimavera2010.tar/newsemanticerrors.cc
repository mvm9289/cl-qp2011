void errornoshadow(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Procedure or function "<<s<<" does not hide any existing one."<<endl;
}
